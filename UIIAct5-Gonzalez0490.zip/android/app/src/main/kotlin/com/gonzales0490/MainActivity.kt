package com.gonzales0490

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
